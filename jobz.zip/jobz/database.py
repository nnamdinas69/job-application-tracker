import mysql.connector

DB_CONFIG = {
    "host":     "localhost",
    "user":     "root",
    "password": "nnamdinwajide",
    "database": "job_tracker",
    "unix_socket": "/tmp/mysql.sock"
}

def get_connection():
    return mysql.connector.connect(**DB_CONFIG)
