# Job Application Tracker

A Flask web application to track job applications, companies, contacts, and job matches.

## Setup Instructions

### 1. Install Python dependencies
```bash
pip3 install -r requirements.txt
```

### 2. Set up MySQL database
Open MySQL and run:
```sql
 schemaaa.sql
```
Or paste the contents of `schemaaaa.sql`/ into MySQL Workbench and execute.

### 3. Configure database connection
Open `database.py` and update the `DB_CONFIG`:
```python
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'nnamdinwajide',  
    'database': 'job_tracker'
}
```

### 4. Run the application
```bash
python3 app.py
```

### 5. Open in browser
Go to: http://127.0.0.1:5000

## Features
- **Companies**: Add/edit/delete companies
- **Jobs**: Track job postings with required skills and salary
- **Applications**: Track application status (Applied, Interview, Offer, etc.)
- **Contacts**: Store recruiter/hiring manager info
- **Job Match**: Enter your skills and see % match for each job

## Project Structure
```
job_tracker/
├── app.py              # Flask routes
├── database.py         # Database functions
├── schema.sql          # Database creation script
├── requirements.txt    # Python dependencies
├── README.md
├── AI_USAGE.md
├── templates/          # HTML pages
│   ├── base.html
│   ├── dashboard.html
│   ├── companies.html
│   ├── company_form.html
│   ├── jobs.html
│   ├── job_form.html
│   ├── applications.html
│   ├── application_form.html
│   ├── contacts.html
│   ├── contact_form.html
│   └── job_match.html
└── static/
    └── style.css
```


setup:
put schemaaa.sql into mysql this is the actual database from assignments 1-6

schema.sql is the structure 

CRUDquries file is the crud quries you can use


put app.py in either pycharm,or vscode if that doesnt work i also used the terminal in mac to great affect and that helped me run the app.py program

assuming you do all this templates for company.html and the other html files should run in the background 


