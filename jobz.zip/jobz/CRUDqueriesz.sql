-- ============================================================
--  queries.sql  —  CRUD Queries for Job Tracker
-- ============================================================


-- ============================================================
--  COMPANIES
-- ============================================================

-- 1. CREATE (INSERT)
-- Adds a new company to the table.
INSERT INTO companies (company_name, industry, website, city, state, notes)
VALUES ('Tech Solutions Inc', 'Technology', 'www.techsolutions.com', 'Miami', 'Florida', NULL);

-- 2. READ (SELECT)
-- Select all companies:
SELECT * FROM companies;

-- Select a specific company by ID:
SELECT company_name, industry, city, state
FROM companies
WHERE company_id = 1;

-- 3. UPDATE
-- Changes the website for a specific company.
UPDATE companies
SET website = 'www.newtechsolutions.com'
WHERE company_id = 1;

-- 4. DELETE
-- Removes a company from the table.
DELETE FROM companies
WHERE company_id = 1;


-- ============================================================
--  JOBS
-- ============================================================

-- 1. CREATE (INSERT)
-- Adds a new job posting to the table.
INSERT INTO jobs (company_id, job_title, job_description, salary_min, salary_max, job_type, posting_url, date_posted, is_active)
VALUES (1, 'Software Developer', 'Build and maintain web applications.', 70000, 90000, 'Full-time', 'www.jobboard.com/job1', '2025-01-15', 1);

-- 2. READ (SELECT)
-- Select all jobs with their company name:
SELECT j.job_id, j.job_title, j.salary_min, j.salary_max, c.company_name
FROM jobs j
JOIN companies c ON j.company_id = c.company_id;

-- Select a specific job by ID:
SELECT * FROM jobs
WHERE job_id = 1;

-- 3. UPDATE
-- Changes the salary range for a specific job.
UPDATE jobs
SET salary_min = 75000, salary_max = 95000
WHERE job_id = 1;

-- 4. DELETE
-- Removes a job posting from the table.
DELETE FROM jobs
WHERE job_id = 1;


-- ============================================================
--  APPLICATIONS
-- ============================================================

-- 1. CREATE (INSERT)
-- Adds a new job application to the table.
INSERT INTO applications (job_id, application_date, status, resume_version, cover_letter_sent, notes)
VALUES (1, '2025-01-16', 'Applied', 'v2.1', 1, 'Applied through company website.');

-- 2. READ (SELECT)
-- Select all applications with job title and company name:
SELECT a.application_id, a.application_date, a.status, j.job_title, c.company_name
FROM applications a
JOIN jobs j      ON a.job_id     = j.job_id
JOIN companies c ON j.company_id = c.company_id;

-- Select a specific application by ID:
SELECT * FROM applications
WHERE application_id = 1;

-- 3. UPDATE
-- Changes the status of an application.
UPDATE applications
SET status = 'Interview', interview_date = '2025-01-25 10:00:00'
WHERE application_id = 1;

-- 4. DELETE
-- Removes an application from the table.
DELETE FROM applications
WHERE application_id = 1;


-- ============================================================
--  CONTACTS
-- ============================================================

-- 1. CREATE (INSERT)
-- Adds a new contact to the table.
INSERT INTO contacts (company_id, first_name, last_name, email, phone, job_title, linkedin_url, notes)
VALUES (1, 'Sarah', 'Johnson', 'sjohnson@techsolutions.com', NULL, 'HR Manager', NULL, NULL);

-- 2. READ (SELECT)
-- Select all contacts with their company name:
SELECT ct.contact_id, ct.first_name, ct.last_name, ct.email, ct.job_title, c.company_name
FROM contacts ct
JOIN companies c ON ct.company_id = c.company_id;

-- Select a specific contact by ID:
SELECT * FROM contacts
WHERE contact_id = 1;

-- 3. UPDATE
-- Updates the email and phone for a specific contact.
UPDATE contacts
SET email = 'sarah.j@techsolutions.com', phone = '305-555-1234'
WHERE contact_id = 1;

-- 4. DELETE
-- Removes a contact from the table.
DELETE FROM contacts
WHERE contact_id = 1;
