# AI Usage Documentation

## Tools Used
- Claude (claude.ai) — used throughout the entire project

---

## Database Setup & Debugging

### Prompts I Used
- "What do I do to check that the server overall is functional after creating tables?"
- "Can I comment out the table creation and check if its still available?"

### What AI Generated
- A 7-step server health check process (SHOW TABLES, DESCRIBE, foreign key verification, test inserts, JOIN query, constraint test, cleanup)
- Explanation of how to comment out SQL using --, #, and /* */

### Errors AI Helped Me Debug
| Error | Cause | Fix |
|-------|-------|-----|
| Error 1050 - Table already exists | Ran CREATE TABLE twice | Added IF NOT EXISTS |
| Error 1292 - Incorrect date value | Space inside date string '2025-01- 10' | Removed the space |
| Error 1452 - Foreign key constraint fails | INSERT used job_id values that didn't exist | Matched job_ids to actual table values (43-59) |
| Error 1054 - Unknown column | Used wrong column name (contact_name vs first_name) | Ran DESCRIBE contacts to check actual columns |
| Duplicate rows in query results | Same INSERT ran 3 times | Deleted duplicate rows with DELETE WHERE application_id NOT IN (...) |

### What I Modified
- Changed all job_id values in application inserts from (1,3,4,5,7) to (43,45,46,47,49) to match my actual AUTO_INCREMENT values
- Fixed ENUM values: 'Interview Scheduled' → 'Interview', 'Phone Screen' → 'Screening'
- Fixed string concatenation in transaction from + operator (SQL Server syntax) to CONCAT() (MySQL syntax)

### What I Learned
- AUTO_INCREMENT counters keep incrementing even when inserts fail, which is why my job IDs started at 43 instead of 1
- Foreign keys block inserts that reference non-existent parent rows — you must insert parent records first
- ENUM columns only accept the exact values defined at table creation
- Deleting in the wrong order (parent before child) breaks foreign key constraints
- Commenting out SQL does not affect the actual data in the database

---

## Flask Application (app.py)

### Prompts I Used
- "What should this code do? pip install flask mysql-connector-python"
- "Is the code the teacher gave enough for this requirement?"

### What AI Generated
- Complete app.py with routes for all 4 tables
- Dashboard route showing counts from all 4 tables and recent applications
- Job Match feature that reads JSON requirements column and calculates skill match percentage

### What I Modified
- Replaced YOUR_PASSWORD with my actual MySQL root password
- Kept teacher's original get_db() connection structure as the base

### What I Learned
- Flask routes use @app.route() to connect URLs to Python functions
- render_template() sends data from Python to HTML files
- The templates folder is required — Flask looks there automatically
- Each button click in a web app runs a CRUD query behind the scenes

---

## HTML Templates

### Prompts I Used
- "Do one for company HTML and then would I be able to just copy that one and change it around a little?"
- "What application do I put the HTML code on?"

### What AI Generated
- companies.html — full list page with table, Edit/Delete buttons, flash messages, nav bar
- Explanation of folder structure (templates/ folder inside project folder)
- Guidance on which parts to change when copying the template for other pages



### What I Learned
- HTML files for Flask go inside a folder called templates
- VS Code is the recommended editor for managing project files


---



## Summary

I used Claude throughout this project primarily for:
1. Debugging MySQL errors in real time
2. Understanding why errors occurred, not just fixing them
3. Generating HTML templates 
4. Building the complete Flask app.py html foundation

 
