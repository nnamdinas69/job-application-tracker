from flask import Flask, render_template, request, redirect, url_for, flash
import crud

app = Flask(__name__)
app.secret_key = 'jobtracker_secret_key'

# ── DASHBOARD ──────────────────────────────────────────────
@app.route('/')
def dashboard():
    stats = crud.get_dashboard_stats()
    return render_template('dashboard.html', **stats)

# ── COMPANIES ──────────────────────────────────────────────
@app.route('/companies')
def companies():
    return render_template('companies.html', companies=crud.read_all_companies())

@app.route('/companies/add', methods=['GET', 'POST'])
def add_company():
    if request.method == 'POST':
        crud.create_company(request.form)
        flash('Company added!')
        return redirect(url_for('companies'))
    return render_template('company_form.html', company=None)

@app.route('/companies/edit/<int:company_id>', methods=['GET', 'POST'])
def edit_company(company_id):
    if request.method == 'POST':
        crud.update_company(company_id, request.form)
        flash('Company updated!')
        return redirect(url_for('companies'))
    return render_template('company_form.html', company=crud.read_company(company_id))

@app.route('/companies/delete/<int:company_id>')
def delete_company(company_id):
    crud.delete_company(company_id)
    flash('Company deleted.')
    return redirect(url_for('companies'))

# ── JOBS ───────────────────────────────────────────────────
@app.route('/jobs')
def jobs():
    return render_template('jobs.html', jobs=crud.read_all_jobs())

@app.route('/jobs/add', methods=['GET', 'POST'])
def add_job():
    if request.method == 'POST':
        crud.create_job(request.form)
        flash('Job added!')
        return redirect(url_for('jobs'))
    return render_template('job_form.html', job=None, companies=crud.read_all_companies())

@app.route('/jobs/edit/<int:job_id>', methods=['GET', 'POST'])
def edit_job(job_id):
    if request.method == 'POST':
        crud.update_job(job_id, request.form)
        flash('Job updated!')
        return redirect(url_for('jobs'))
    return render_template('job_form.html', job=crud.read_job(job_id), companies=crud.read_all_companies())

@app.route('/jobs/delete/<int:job_id>')
def delete_job(job_id):
    crud.delete_job(job_id)
    flash('Job deleted.')
    return redirect(url_for('jobs'))

# ── APPLICATIONS ───────────────────────────────────────────
@app.route('/applications')
def applications():
    return render_template('applications.html', applications=crud.read_all_applications())

@app.route('/applications/add', methods=['GET', 'POST'])
def add_application():
    if request.method == 'POST':
        crud.create_application(request.form)
        flash('Application added!')
        return redirect(url_for('applications'))
    return render_template('application_form.html', application=None, jobs=crud.read_all_jobs())

@app.route('/applications/edit/<int:application_id>', methods=['GET', 'POST'])
def edit_application(application_id):
    if request.method == 'POST':
        crud.update_application(application_id, request.form)
        flash('Application updated!')
        return redirect(url_for('applications'))
    return render_template('application_form.html',
                           application=crud.read_application(application_id),
                           jobs=crud.read_all_jobs())

@app.route('/applications/delete/<int:application_id>')
def delete_application(application_id):
    crud.delete_application(application_id)
    flash('Application deleted.')
    return redirect(url_for('applications'))

# ── CONTACTS ───────────────────────────────────────────────
@app.route('/contacts')
def contacts():
    return render_template('contacts.html', contacts=crud.read_all_contacts())

@app.route('/contacts/add', methods=['GET', 'POST'])
def add_contact():
    if request.method == 'POST':
        crud.create_contact(request.form)
        flash('Contact added!')
        return redirect(url_for('contacts'))
    return render_template('contact_form.html', contact=None, companies=crud.read_all_companies())

@app.route('/contacts/edit/<int:contact_id>', methods=['GET', 'POST'])
def edit_contact(contact_id):
    if request.method == 'POST':
        crud.update_contact(contact_id, request.form)
        flash('Contact updated!')
        return redirect(url_for('contacts'))
    return render_template('contact_form.html',
                           contact=crud.read_contact(contact_id),
                           companies=crud.read_all_companies())

@app.route('/contacts/delete/<int:contact_id>')
def delete_contact(contact_id):
    crud.delete_contact(contact_id)
    flash('Contact deleted.')
    return redirect(url_for('contacts'))

# ── JOB MATCH ──────────────────────────────────────────────
@app.route('/job-match', methods=['GET', 'POST'])
def job_match():
    results = None
    user_skills = ''
    if request.method == 'POST':
        user_skills = request.form.get('skills', '')
        results = crud.job_match(user_skills)
    return render_template('job_match.html', results=results, user_skills=user_skills)

if __name__ == '__main__':
    app.run(debug=True)
